library youtube_search_result;

import 'dart:convert';

import 'package:built_collection/built_collection.dart';
import 'package:built_value/built_value.dart';
import 'package:built_value/serializer.dart';
import 'package:youtube_search/data/model/search/search_item.dart';
import 'package:youtube_search/data/model/serializer/serializers.dart';
part 'youtube_search_result.g.dart';

abstract class YoutubesearchResult
    implements Built<YoutubesearchResult, YoutubesearchResultBuilder> {
  String get nextpagetoken;
  BuiltList<SearchItem> get items;
  YoutubesearchResult._();

  factory YoutubesearchResult([updates(YoutubesearchResultBuilder b)]) =
      _$YoutubesearchResult;

  String toJson() {
    return json.encode(
        serializers.serializeWith(YoutubesearchResult.serializer, this));
  }

  static YoutubesearchResult fromJson(String jsonString) {
    return serializers.deserializeWith(
        YoutubesearchResult.serializer, json.decode(jsonString));
  }

  static Serializer<YoutubesearchResult> get serializer =>
      _$youtubesearchResultSerializer;
}
