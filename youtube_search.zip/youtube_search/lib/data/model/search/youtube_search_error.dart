class YoutubeSearchError implements Exception {
  final String errormessage;
  YoutubeSearchError(this.errormessage);
}
