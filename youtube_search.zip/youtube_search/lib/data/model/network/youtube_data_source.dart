import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:youtube_search/data/model/search/model_search.dart';

class YoutubeDataSource {
  final String searchUrl =
      'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=5&type=video&key=AIzaSyDS89iTeCcWB-d9ShyqN9q3LeGDpj1vP8w';

  Future<YoutubesearchResult> searchVideos({
    String query,
    String pageToken = '',
  }) async {
    final urlRaw = searchUrl +
        '&q=$query' +
        (pageToken.isNotEmpty ? '&pageToken=$pageToken' : '');

    final urlEncoded = Uri.encodeFull(urlRaw);
    final response = await http.get(urlEncoded);

    if (response.statusCode == 200) {
      return YoutubesearchResult.fromJson(response.body);
    } else {
      throw YoutubeSearchError(json.decode(response.body)['error']['message']);
    }
  }
}
